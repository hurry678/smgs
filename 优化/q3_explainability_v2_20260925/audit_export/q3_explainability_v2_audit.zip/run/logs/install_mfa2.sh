#!/usr/bin/env bash
set -euo pipefail
RUN=/data2/hy/q3_runs/q3_explainability_v2_20260925
CONDA=/data2/hy/anaconda3/bin/conda
cd "$RUN/.mfa_pkgs"

echo "=== building explicit list ==="
{
  echo "@EXPLICIT"
  for f in *.conda *.tar.bz2; do
    h=$(md5sum "$f" | cut -d' ' -f1)
    echo "file://$PWD/$f#$h"
  done
} > explicit_specs.txt
wc -l explicit_specs.txt
head -3 explicit_specs.txt
grep -n 'x264' explicit_specs.txt || true

echo "=== conda create from explicit list (offline) ==="
"$CONDA" create -p "$RUN/.mfa" --offline --yes --file explicit_specs.txt 2>&1 | tee "$RUN/logs/mfa_install.log"
echo "=== conda exit: ${PIPESTATUS[0]} ==="