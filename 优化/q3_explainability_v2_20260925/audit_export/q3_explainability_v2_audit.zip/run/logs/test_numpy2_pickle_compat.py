#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import pickle
import sys
from pathlib import Path

import numpy as np


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    raw = Path(sys.argv[1])
    records = []
    errors = []
    for split in ("对齐版本", "未对齐版本"):
        files = sorted((raw / split).glob("*.pkl"))
        if len(files) != 20:
            errors.append(f"{split}: expected 20 pkl, found {len(files)}")
        for path in files:
            try:
                with path.open("rb") as f:
                    obj = pickle.load(f)
                if not isinstance(obj, dict):
                    raise TypeError(f"top-level type is {type(obj).__name__}, expected dict")
                shapes = {}
                finite = {}
                for key, value in obj.items():
                    if isinstance(value, np.ndarray):
                        shapes[key] = list(value.shape)
                        if np.issubdtype(value.dtype, np.number):
                            finite[key] = bool(np.isfinite(value).all())
                records.append(
                    {
                        "split": split,
                        "file": path.name,
                        "sha256": sha256_file(path),
                        "id": str(obj.get("id")),
                        "keys": sorted(str(k) for k in obj),
                        "shapes": shapes,
                        "finite": finite,
                    }
                )
            except Exception as exc:
                errors.append(f"{split}/{path.name}: {type(exc).__name__}: {exc}")
    result = {
        "numpy_version": np.__version__,
        "compat_env": __import__("os").environ.get("Q3_NUMPY2_PICKLE_COMPAT"),
        "n_aligned": sum(r["split"] == "对齐版本" for r in records),
        "n_unaligned": sum(r["split"] == "未对齐版本" for r in records),
        "n_errors": len(errors),
        "errors": errors,
        "records": records,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())