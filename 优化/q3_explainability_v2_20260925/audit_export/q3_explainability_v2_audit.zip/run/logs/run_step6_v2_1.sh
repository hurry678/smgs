#!/usr/bin/env bash
set -euo pipefail
REPO=/data2/hy/smgs
LEGACY=/data2/hy/cts/e_problem
RUN=/data2/hy/q3_runs/q3_explainability_v2_20260925
PY=/data2/hy/anaconda3/envs/secgpt-vllm/bin/python
RAW="/data2/hy/test_5/E题/E题数据/E题数据/附件4-可解释专项视频样本与特征文件/附件4-可解释专项视频样本与特征文件"
MFA="$RUN/.mfa/bin/mfa"
MFA_DICT="$RUN/resources/mfa/english_mfa_dictionary_v3.1.0.dict"
MFA_ACOUSTIC="$RUN/resources/mfa/english_mfa_acoustic_v3.1.0.zip"
MFA_G2P="$RUN/resources/mfa/english_us_mfa_g2p_v3.0.0.zip"
unset Q3_NUMPY2_PICKLE_COMPAT || true
export PYTHONPATH="$RUN/python_deps"
"$PY" "$RUN/scripts/q3_prepare_alignment_v2_1.py" \
  --raw-dir "$RAW" \
  --attachment4 "$RUN/attachment4_data/attachment4_aligned.npz" \
  --offsets "$RUN/attachment4_offsets.npz" \
  --base-audit "$RUN/attachment4_data/attachment4_audit.json" \
  --out-audit "$RUN/alignment_audit.json" \
  --work-dir "$RUN/mfa_work" \
  --mfa-executable "$MFA" \
  --mfa-root-dir "$RUN/mfa_cache" \
  --dictionary "$MFA_DICT" \
  --acoustic-model "$MFA_ACOUSTIC" \
  --g2p-model "$MFA_G2P" \
  --expected-mfa-version 3.4.1 \
  --num-jobs 1 --min-mfa-sample-rate 0.8 \
  2>&1 | tee "$RUN/logs/alignment.log"
"$PY" -c 'import json,sys; d=json.load(open(sys.argv[1])); print("alignment status:", d.get("status"), "sample_rate:", d.get("mfa_sample_rate")); raise SystemExit(0 if d.get("status") == "PASS" and float(d.get("mfa_sample_rate", 0)) >= 0.8 else 1)' "$RUN/alignment_audit.json"
echo "[$(date '+%F %T')] STEP6 v2_1 done"
