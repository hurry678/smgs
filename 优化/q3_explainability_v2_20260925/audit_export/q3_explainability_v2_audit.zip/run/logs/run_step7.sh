#!/usr/bin/env bash
set -euo pipefail
REPO=/data2/hy/smgs
EXT="$REPO/问题三/q3_explainability_v2_20260925"
LEGACY=/data2/hy/cts/e_problem
RUN=/data2/hy/q3_runs/q3_explainability_v2_20260925
PY=/data2/hy/anaconda3/envs/secgpt-vllm/bin/python
DEVICE=cuda:2
CHECKPOINTS=(
  "$LEGACY/artifacts/q2/final/M0_seed42.pt"
  "$LEGACY/artifacts/q2/final/M0_seed43.pt"
  "$LEGACY/artifacts/q2/final/M0_seed44.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add/M0_seed45.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add/M0_seed46.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add/M0_seed47.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add2/M0_seed48.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add2/M0_seed49.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add2/M0_seed50.pt"
)
unset Q3_NUMPY2_PICKLE_COMPAT || true
export PYTHONPATH="$RUN/python_deps"
mkdir -p "$RUN/final_attachment4"
/usr/bin/time -v "$PY" "$EXT/scripts/q3_explain_core_v2.py" \
  --mode attachment4 \
  --data "$LEGACY/data/q2/q2_data.npz" \
  --attachment4 "$RUN/attachment4_data/attachment4_aligned.npz" \
  --offsets "$RUN/attachment4_offsets.npz" \
  --audit "$RUN/alignment_audit.json" \
  --model-dir "$LEGACY/models/all-MiniLM-L6-v2" \
  --checkpoints "${CHECKPOINTS[@]}" \
  --freeze-manifest "$REPO/ds/artifacts/q2/v3_m3_ensemble9/version_manifest.json" \
  --out-dir "$RUN/final_attachment4" \
  --window-size 3 --stride 3 \
  --point-n 20 --top-k 2 --batch-size 64 --seed 2026 \
  --device "$DEVICE" \
  2>&1 | tee "$RUN/logs/attachment4_inference.log"
echo "[$(date '+%F %T')] STEP7 done"
