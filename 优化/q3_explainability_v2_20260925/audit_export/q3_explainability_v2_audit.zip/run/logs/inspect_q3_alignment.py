#!/usr/bin/env python3
import json
import sys
from pathlib import Path

run = Path("/data2/hy/q3_runs/q3_explainability_v2_20260925")
audit = json.load((run / "alignment_audit.json").open())
print("fallback_ids:", audit.get("fallback_sample_ids"))
print("mfa:", json.dumps(audit.get("mfa"), ensure_ascii=False, indent=2))
if audit.get("samples"):
    print("sample keys:", sorted(audit["samples"][0].keys()))
for sample in audit.get("samples", []):
    sid = str(sample.get("sample_id"))
    if sid not in set(str(x) for x in audit.get("fallback_sample_ids", [])):
        continue
    print("=" * 80)
    print("fallback sample", sid)
    for key in sorted(sample):
        value = sample[key]
        if key == "position_to_time":
            continue
        text = json.dumps(value, ensure_ascii=False)
        print(key, "=", text[:4000])
    pts = sample.get("position_to_time") or []
    status_counts = {}
    for row in pts:
        status_counts[row.get("status")] = status_counts.get(row.get("status"), 0) + 1
    print("position_to_time_status_counts =", status_counts)
    print("n_position_to_time =", len(pts))