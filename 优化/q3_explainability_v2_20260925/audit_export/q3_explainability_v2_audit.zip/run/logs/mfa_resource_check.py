"""Resource readiness check: load the three official MFA models with the isolated MFA 3.4.1 env.

Does NOT touch attachment4 / official test / attachment3.
"""
import hashlib
import importlib.metadata as md
import json
import os
import sys

RUN = "/data2/hy/q3_runs/q3_explainability_v2_20260925"
RES = os.path.join(RUN, "resources", "mfa")

EXPECTED = {
    "english_mfa_dictionary_v3.1.0.dict": "975bf9c7791535c5aec57995e0bd2b77eb7ca364d1d974c2134e07bb0f16b079",
    "english_mfa_acoustic_v3.1.0.zip": "2c08bd4f82c3943dd57ac09aeac99dbce17a1e1bfe9fd932c8d95cd13d971068",
    "english_us_mfa_g2p_v3.0.0.zip": "9923b38d59a8b3e3e322f225c52523c2a6248e5ffc9fd89be151ade2dc97cb02",
}

report = {"schema": "q3v2-mfa-resource-check-v1", "mfa_version": None, "files": [], "load": {}, "status": "FAIL"}

report["mfa_version"] = md.version("montreal-forced-aligner")

for name, exp in EXPECTED.items():
    p = os.path.join(RES, name)
    h = hashlib.sha256(open(p, "rb").read()).hexdigest()
    report["files"].append({"file": name, "size": os.path.getsize(p), "sha256": h,
                            "expected_sha256": exp, "match": h == exp})

from pathlib import Path as _Path

from montreal_forced_aligner.models import AcousticModel, DictionaryModel, G2PModel

for label, cls, name in (
    ("dictionary", DictionaryModel, "english_mfa_dictionary_v3.1.0.dict"),
    ("acoustic", AcousticModel, "english_mfa_acoustic_v3.1.0.zip"),
    ("g2p", G2PModel, "english_us_mfa_g2p_v3.0.0.zip"),
):
    p = os.path.join(RES, name)
    try:
        m = cls(_Path(p))
        report["load"][label] = {
            "ok": True,
            "name": getattr(m, "name", None),
            "version": getattr(m, "version", None),
            "path": str(getattr(m, "path", p)),
        }
    except Exception as exc:  # noqa: BLE001
        report["load"][label] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

report["status"] = "PASS" if (
    all(f["match"] for f in report["files"])
    and all(v.get("ok") for v in report["load"].values())
) else "FAIL"

out = os.path.join(RUN, "logs", "mfa_resource_check.json")
with open(out, "w") as fh:
    json.dump(report, fh, indent=2, ensure_ascii=False)
print(json.dumps(report, indent=2, ensure_ascii=False))
sys.exit(0 if report["status"] == "PASS" else 1)