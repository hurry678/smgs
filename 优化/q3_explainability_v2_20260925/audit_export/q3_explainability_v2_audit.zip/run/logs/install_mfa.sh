#!/usr/bin/env bash
set -euo pipefail
RUN=/data2/hy/q3_runs/q3_explainability_v2_20260925
CONDA=/data2/hy/anaconda3/bin/conda
cd "$RUN"

echo "=== model SHA verification (server side) ==="
cd "$RUN/resources/mfa"
sha256sum english_mfa_dictionary_v3.1.0.dict english_mfa_acoustic_v3.1.0.zip english_us_mfa_g2p_v3.0.0.zip
cd "$RUN"

echo "=== conda pkg inventory ==="
cd "$RUN/.mfa_pkgs"
n_conda=$(ls -1 *.conda 2>/dev/null | wc -l)
n_tbz=$(ls -1 *.tar.bz2 2>/dev/null | wc -l)
echo "conda=$n_conda tar.bz2=$n_tbz total=$((n_conda+n_tbz))"
printf '%s\n' "$PWD"/*.conda "$PWD"/*.tar.bz2 > "$RUN/.mfa_pkgs/pkg_abs_paths.txt"
wc -l "$RUN/.mfa_pkgs/pkg_abs_paths.txt"

echo "=== conda create (offline, isolated prefix) ==="
"$CONDA" create -p "$RUN/.mfa" --offline --yes --file "$RUN/.mfa_pkgs/pkg_abs_paths.txt" 2>&1 | tee "$RUN/logs/mfa_install.log"
echo "=== exit code: $? ==="