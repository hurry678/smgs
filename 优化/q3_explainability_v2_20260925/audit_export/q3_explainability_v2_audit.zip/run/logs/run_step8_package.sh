#!/usr/bin/env bash
set -euo pipefail
REPO=/data2/hy/smgs
EXT="$REPO/问题三/q3_explainability_v2_20260925"
LEGACY=/data2/hy/cts/e_problem
RUN=/data2/hy/q3_runs/q3_explainability_v2_20260925
PY=/data2/hy/anaconda3/envs/secgpt-vllm/bin/python
unset Q3_NUMPY2_PICKLE_COMPAT || true
export PYTHONPATH="$RUN/python_deps"
mkdir -p "$RUN/submission"
"$PY" "$EXT/scripts/q3_build_outputs_v2.py" \
  --raw-json "$RUN/final_attachment4/q3_attachment4_raw.json" \
  --out-dir "$RUN/submission" \
  --attachment4 "$RUN/attachment4_data/attachment4_aligned.npz" \
  --model-manifest "$REPO/ds/artifacts/q2/v3_m3_ensemble9/version_manifest.json" \
  --explain-script "$EXT/scripts/q3_explain_core_v2.py" \
  --alignment-script "$RUN/scripts/q3_prepare_alignment_v2_1.py" \
  --math-script "$EXT/scripts/q3v2_math.py" \
  --data "$LEGACY/data/q2/q2_data.npz" \
  --offsets "$RUN/attachment4_offsets.npz" \
  --audit "$RUN/alignment_audit.json" \
  --validation-report "$RUN/validation/w3/q3_validation_report.json" \
  --explanation-parameters "$RUN/freeze_parameters.json" \
  2>&1 | tee "$RUN/logs/package.log"
echo "[$(date '+%F %T')] STEP8 package done"
