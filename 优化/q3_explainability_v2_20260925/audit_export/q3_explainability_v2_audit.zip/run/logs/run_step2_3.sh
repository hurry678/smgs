#!/usr/bin/env bash
set -euo pipefail
REPO=/data2/hy/smgs
EXT="$REPO/问题三/q3_explainability_v2_20260925"
LEGACY=/data2/hy/cts/e_problem
RUN=/data2/hy/q3_runs/q3_explainability_v2_20260925
PY=/data2/hy/anaconda3/envs/secgpt-vllm/bin/python
DEVICE=cuda:2
export PYTHONPATH="$RUN/python_deps"

CHECKPOINTS=(
  "$LEGACY/artifacts/q2/final/M0_seed42.pt"
  "$LEGACY/artifacts/q2/final/M0_seed43.pt"
  "$LEGACY/artifacts/q2/final/M0_seed44.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add/M0_seed45.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add/M0_seed46.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add/M0_seed47.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add2/M0_seed48.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add2/M0_seed49.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add2/M0_seed50.pt"
)

echo "[$(date '+%F %T')] STEP2 start"
"$PY" "$EXT/scripts/q3_prepare_offsets_v2.py" \
  --scope q2 \
  --q2-data "$LEGACY/data/q2/q2_data.npz" \
  --q2-splits valid \
  --model-dir "$LEGACY/models/all-MiniLM-L6-v2" \
  --out "$RUN/q2_valid_offsets.npz" \
  --audit-json "$RUN/q2_valid_offsets_audit.json" \
  2>&1 | tee "$RUN/logs/q2_valid_offsets.log"
echo "[$(date '+%F %T')] STEP2 done"

for W in 3 5 10; do
  mkdir -p "$RUN/validation/w$W"
  echo "[$(date '+%F %T')] STEP3 W=$W start"
  /usr/bin/time -v "$PY" "$EXT/scripts/q3_explain_core_v2.py" \
    --mode validation \
    --data "$LEGACY/data/q2/q2_data.npz" \
    --offsets "$RUN/q2_valid_offsets.npz" \
    --model-dir "$LEGACY/models/all-MiniLM-L6-v2" \
    --checkpoints "${CHECKPOINTS[@]}" \
    --freeze-manifest "$REPO/ds/artifacts/q2/v3_m3_ensemble9/version_manifest.json" \
    --out-dir "$RUN/validation/w$W" \
    --split valid --n 728 \
    --window-size "$W" --stride "$W" \
    --point-n 128 --top-k 2 --batch-size 64 --seed 2026 \
    --device "$DEVICE" \
    2>&1 | tee "$RUN/logs/validation_w$W.log"
  echo "[$(date '+%F %T')] STEP3 W=$W done"
done
echo "[$(date '+%F %T')] STEP3 all done"