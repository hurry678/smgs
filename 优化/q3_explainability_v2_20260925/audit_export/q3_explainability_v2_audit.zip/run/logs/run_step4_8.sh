#!/usr/bin/env bash
set -euo pipefail
REPO=/data2/hy/smgs
EXT="$REPO/问题三/q3_explainability_v2_20260925"
LEGACY=/data2/hy/cts/e_problem
RUN=/data2/hy/q3_runs/q3_explainability_v2_20260925
PY=/data2/hy/anaconda3/envs/secgpt-vllm/bin/python
DEVICE=cuda:2
export PYTHONPATH="$RUN/python_deps"

RAW="/data2/hy/test_5/E题/E题数据/E题数据/附件4-可解释专项视频样本与特征文件/附件4-可解释专项视频样本与特征文件"
MFA="$RUN/.mfa/bin/mfa"
MFA_DICT="$RUN/resources/mfa/english_mfa_dictionary_v3.1.0.dict"
MFA_ACOUSTIC="$RUN/resources/mfa/english_mfa_acoustic_v3.1.0.zip"
MFA_G2P="$RUN/resources/mfa/english_us_mfa_g2p_v3.0.0.zip"

CHECKPOINTS=(
  "$LEGACY/artifacts/q2/final/M0_seed42.pt"
  "$LEGACY/artifacts/q2/final/M0_seed43.pt"
  "$LEGACY/artifacts/q2/final/M0_seed44.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add/M0_seed45.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add/M0_seed46.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add/M0_seed47.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add2/M0_seed48.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add2/M0_seed49.pt"
  "$LEGACY/artifacts/q2/v2_m0_ensemble_add2/M0_seed50.pt"
)

echo "[$(date '+%F %T')] STEP4 start (freeze interpretation parameters, validation-only)"
"$PY" "$EXT/scripts/q3_select_freeze_v2.py" \
  --report "3=$RUN/validation/w3/q3_validation_report.json" \
  --report "5=$RUN/validation/w5/q3_validation_report.json" \
  --report "10=$RUN/validation/w10/q3_validation_report.json" \
  --out "$RUN/freeze_parameters.json" \
  --expected-n 728 --fallback-window 5 \
  --point-scan-n 128 --top-k 2 --batch-size 64 --seed 2026 \
  --q2-freeze-manifest "$REPO/优化/q2yhv2_1/server_results_20260925/freeze_manifest.json" \
  --q2-version-manifest "$REPO/ds/artifacts/q2/v3_m3_ensemble9/version_manifest.json" \
  2>&1 | tee "$RUN/logs/freeze_parameters.log"

W=$("$PY" -c 'import json,sys; print(json.load(open(sys.argv[1]))["selected_window_size"])' "$RUN/freeze_parameters.json")
echo "[$(date '+%F %T')] STEP4 done: selected window W=$W"
case "$W" in 3|5|10) ;; *) echo "INVALID W=$W"; exit 1;; esac
SELECTED_REPORT="$RUN/validation/w$W/q3_validation_report.json"
echo "$W" > "$RUN/logs/selected_window.txt"
echo "$SELECTED_REPORT" > "$RUN/logs/selected_report_path.txt"

echo "[$(date '+%F %T')] STEP5 start (FIRST READ of attachment4)"
"$PY" "$EXT/scripts/q3_preflight_v2.py" \
  --scope attachment4 \
  --protocol "$EXT/configs/protocol.json" \
  --repo-root "$REPO" \
  --legacy-root "$LEGACY" \
  --raw-dir "$RAW" \
  --mfa-executable "$MFA" \
  --dictionary "$MFA_DICT" \
  --acoustic-model "$MFA_ACOUSTIC" \
  --g2p-model "$MFA_G2P" \
  --out "$RUN/preflight_attachment4.json" \
  2>&1 | tee "$RUN/logs/preflight_attachment4.log"

"$PY" -c "import json,sys;d=json.load(open('$RUN/preflight_attachment4.json'));print('attachment4 preflight status:',d['status']);sys.exit(0 if d['status']=='PASS' else 1)"

"$PY" "$EXT/scripts/prepare_q3_data_v2.py" \
  --raw-dir "$RAW" \
  --model-dir "$LEGACY/models/all-MiniLM-L6-v2" \
  --out-dir "$RUN/attachment4_data" \
  2>&1 | tee "$RUN/logs/prepare_attachment4.log"

"$PY" "$EXT/scripts/q3_prepare_offsets_v2.py" \
  --scope attachment4 \
  --attachment4 "$RUN/attachment4_data/attachment4_aligned.npz" \
  --model-dir "$LEGACY/models/all-MiniLM-L6-v2" \
  --out "$RUN/attachment4_offsets.npz" \
  --audit-json "$RUN/attachment4_offsets_audit.json" \
  2>&1 | tee "$RUN/logs/attachment4_offsets.log"
echo "[$(date '+%F %T')] STEP5 done"

echo "[$(date '+%F %T')] STEP6 start (MFA alignment)"
"$PY" "$EXT/scripts/q3_prepare_alignment_v2.py" \
  --raw-dir "$RAW" \
  --attachment4 "$RUN/attachment4_data/attachment4_aligned.npz" \
  --offsets "$RUN/attachment4_offsets.npz" \
  --base-audit "$RUN/attachment4_data/attachment4_audit.json" \
  --out-audit "$RUN/alignment_audit.json" \
  --work-dir "$RUN/mfa_work" \
  --mfa-executable "$MFA" \
  --mfa-root-dir "$RUN/mfa_cache" \
  --dictionary "$MFA_DICT" \
  --acoustic-model "$MFA_ACOUSTIC" \
  --g2p-model "$MFA_G2P" \
  --expected-mfa-version 3.4.1 \
  --num-jobs 1 --min-mfa-sample-rate 0.8 \
  2>&1 | tee "$RUN/logs/alignment.log"
echo "[$(date '+%F %T')] STEP6 done"

echo "[$(date '+%F %T')] STEP7 start (frozen attachment4 inference)"
mkdir -p "$RUN/final_attachment4"
/usr/bin/time -v "$PY" "$EXT/scripts/q3_explain_core_v2.py" \
  --mode attachment4 \
  --data "$LEGACY/data/q2/q2_data.npz" \
  --attachment4 "$RUN/attachment4_data/attachment4_aligned.npz" \
  --offsets "$RUN/attachment4_offsets.npz" \
  --audit "$RUN/alignment_audit.json" \
  --model-dir "$LEGACY/models/all-MiniLM-L6-v2" \
  --checkpoints "${CHECKPOINTS[@]}" \
  --freeze-manifest "$REPO/ds/artifacts/q2/v3_m3_ensemble9/version_manifest.json" \
  --out-dir "$RUN/final_attachment4" \
  --window-size "$W" --stride "$W" \
  --point-n 20 --top-k 2 --batch-size 64 --seed 2026 \
  --device "$DEVICE" \
  2>&1 | tee "$RUN/logs/attachment4_inference.log"
echo "[$(date '+%F %T')] STEP7 done"

echo "[$(date '+%F %T')] STEP8 start (package + independent verification + audit export)"
mkdir -p "$RUN/submission"
"$PY" "$EXT/scripts/q3_build_outputs_v2.py" \
  --raw-json "$RUN/final_attachment4/q3_attachment4_raw.json" \
  --out-dir "$RUN/submission" \
  --attachment4 "$RUN/attachment4_data/attachment4_aligned.npz" \
  --model-manifest "$REPO/ds/artifacts/q2/v3_m3_ensemble9/version_manifest.json" \
  --explain-script "$EXT/scripts/q3_explain_core_v2.py" \
  --alignment-script "$EXT/scripts/q3_prepare_alignment_v2.py" \
  --math-script "$EXT/scripts/q3v2_math.py" \
  --data "$LEGACY/data/q2/q2_data.npz" \
  --offsets "$RUN/attachment4_offsets.npz" \
  --audit "$RUN/alignment_audit.json" \
  --validation-report "$SELECTED_REPORT" \
  --explanation-parameters "$RUN/freeze_parameters.json" \
  2>&1 | tee "$RUN/logs/package.log"

"$PY" "$EXT/scripts/verify_q3v2.py" \
  --repo-root "$REPO" \
  --extension-root "$EXT" \
  --run-dir "$RUN" \
  --out "$RUN/verification.json" \
  2>&1 | tee "$RUN/logs/verify.log"

"$PY" "$EXT/scripts/export_q3v2_audit.py" \
  --extension-root "$EXT" \
  --run-dir "$RUN" \
  --export-dir "$RUN/audit_export" \
  2>&1 | tee "$RUN/logs/export_audit.log"

cd "$RUN/audit_export"
sha256sum -c SHA256SUMS.txt
echo "[$(date '+%F %T')] STEP8 done (verification.json gate passed before any push)"