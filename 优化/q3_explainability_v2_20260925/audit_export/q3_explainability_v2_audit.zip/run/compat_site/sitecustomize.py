"""Process-local compatibility aliases for NumPy 2.x pickles.

This file is loaded via PYTHONPATH by Python's site machinery.  It is opt-in:
nothing is changed unless Q3_NUMPY2_PICKLE_COMPAT=1 is present.  The shared
NumPy 1.26 installation is not modified; only sys.modules aliases are added so
that pickle streams referring to numpy._core.* can be read by NumPy 1.x.
"""

from __future__ import annotations

import importlib
import os
import sys

if os.environ.get("Q3_NUMPY2_PICKLE_COMPAT") == "1":
    import numpy as np

    if np.__version__.split(".", 1)[0] == "1":
        aliases = {
            "numpy._core": "numpy.core",
            "numpy._core._multiarray_umath": "numpy.core._multiarray_umath",
            "numpy._core._multiarray_tests": "numpy.core._multiarray_tests",
            "numpy._core.multiarray": "numpy.core.multiarray",
            "numpy._core.numeric": "numpy.core.numeric",
            "numpy._core.umath": "numpy.core.umath",
            "numpy._core._exceptions": "numpy.core._exceptions",
            "numpy._core._methods": "numpy.core._methods",
            "numpy._core._ufunc_config": "numpy.core._ufunc_config",
            "numpy._core.einsumfunc": "numpy.core.einsumfunc",
            "numpy._core.function_base": "numpy.core.function_base",
            "numpy._core.fromnumeric": "numpy.core.fromnumeric",
            "numpy._core.getlimits": "numpy.core.getlimits",
            "numpy._core.memmap": "numpy.core.memmap",
            "numpy._core.numerictypes": "numpy.core.numerictypes",
            "numpy._core.records": "numpy.core.records",
            "numpy._core.shape_base": "numpy.core.shape_base",
        }
        for alias, target in aliases.items():
            try:
                module = importlib.import_module(target)
            except ImportError:
                continue
            sys.modules.setdefault(alias, module)